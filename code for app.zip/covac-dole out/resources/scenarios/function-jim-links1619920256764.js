(function(window, undefined) {

  var jimLinks = {
    "07fabf3e-7610-40c2-b7d6-e4f6be34495e" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ]
    },
    "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b" : {
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_23" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "33ab7b75-f9e7-482d-a9b2-ce5932d708a4" : {
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "9f360f30-0450-47f9-9b54-cb26dac0ccab" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ]
    },
    "b385e9eb-ecc9-48cb-8c57-9430219bc46f" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ],
      "Two-line-item_43" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_2" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Rectangle_3" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Rectangle_4" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ],
      "Paragraph_2" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Rectangle_1" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Image_44" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Image_45" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Image_46" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Image_47" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ]
    },
    "330edaa3-9581-4140-b862-9b0ca4ad4bbb" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ],
      "Rectangle_2" : [
        "07fabf3e-7610-40c2-b7d6-e4f6be34495e"
      ],
      "Rectangle_3" : [
        "9f360f30-0450-47f9-9b54-cb26dac0ccab"
      ],
      "Rectangle_1" : [
        "c627577d-db87-4fc1-bc52-7ff58e0e1947"
      ],
      "Rectangle_4" : [
        "08b6b339-1d54-4130-afa9-720df9972c35"
      ]
    },
    "4a272366-d80d-4203-9dd9-4b2c52fa0fd9" : {
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_23" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "7af17633-bc62-41c8-9704-cb5dd4bfd47e"
      ]
    },
    "90cefbcd-3696-475d-ac62-da78822a86e3" : {
      "Circle" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Triangle" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ]
    },
    "4100fa47-e71a-4055-af5c-e07a7602f32c" : {
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_23" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"
      ]
    },
    "58530efa-8638-4117-b3de-597bfaa5b18d" : {
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ],
      "Two-line-item_43" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Two-line-item_44" : [
        "b385e9eb-ecc9-48cb-8c57-9430219bc46f"
      ]
    },
    "7af17633-bc62-41c8-9704-cb5dd4bfd47e" : {
      "Circle" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Triangle" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ]
    },
    "0ee15278-8ef7-4452-abd6-e4b481ab1bd2" : {
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_23" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"
      ]
    },
    "56cbf5f8-f23f-4194-937c-aa6f212f9ce6" : {
      "raised_Button_disabled" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ]
    },
    "b7c8aafe-d3ec-4276-b600-0e61c2c875ce" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ]
    },
    "c627577d-db87-4fc1-bc52-7ff58e0e1947" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ]
    },
    "662f1b93-c984-4f38-aec3-d25f79556bd9" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ]
    },
    "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6" : {
      "Rectangle_2" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Rectangle_3" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Rectangle_4" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Paragraph_2" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Image_45" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Paragraph_3" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Image_46" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Paragraph_4" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Image_47" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Rectangle_5" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Paragraph_5" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Image_48" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Rectangle_1" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Paragraph_1" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Image_44" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Image_37" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_7" : [
        "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"
      ]
    },
    "311d36d6-d425-4a4a-b565-383c0993b00d" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ]
    },
    "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6" : {
      "Circle" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Triangle" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ]
    },
    "3fca400d-1926-4a4e-8303-0e864a3c899f" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ],
      "Button_1" : [
        "662f1b93-c984-4f38-aec3-d25f79556bd9",
        "ba50421d-0619-44ae-b061-b5ee98f45737",
        "311d36d6-d425-4a4a-b565-383c0993b00d",
        "92ac0fa0-383d-469b-9900-a1491e953075"
      ]
    },
    "92ac0fa0-383d-469b-9900-a1491e953075" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ]
    },
    "95fed0f1-464f-49cf-b9d9-f69d3c711405" : {
      "Button_1" : [
        "b385e9eb-ecc9-48cb-8c57-9430219bc46f"
      ]
    },
    "08b6b339-1d54-4130-afa9-720df9972c35" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ],
      "Two-line-item_12" : [
        "330edaa3-9581-4140-b862-9b0ca4ad4bbb"
      ],
      "Two-line-item_23" : [
        "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"
      ]
    },
    "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8" : {
      "Circle" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Triangle" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "flat_Button_lightTheme" : [
        "95fed0f1-464f-49cf-b9d9-f69d3c711405"
      ],
      "flat_Button_darkTheme" : [
        "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"
      ]
    },
    "1e637558-86bf-4ac2-a195-9da821046d78" : {
      "Circle" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_34" : [
        "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"
      ],
      "Two-line-item_12" : [
        "4100fa47-e71a-4055-af5c-e07a7602f32c"
      ],
      "Two-line-item_23" : [
        "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"
      ],
      "Two-line-item_28" : [
        "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"
      ],
      "Two-line-item_29" : [
        "1e637558-86bf-4ac2-a195-9da821046d78"
      ],
      "Two-line-item_43" : [
        "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"
      ],
      "Two-line-item_44" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "90cefbcd-3696-475d-ac62-da78822a86e3"
      ]
    },
    "ba50421d-0619-44ae-b061-b5ee98f45737" : {
      "Two-line-item_24" : [
        "58530efa-8638-4117-b3de-597bfaa5b18d"
      ],
      "Two-line-item_34" : [
        "3fca400d-1926-4a4e-8303-0e864a3c899f"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);