	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-BgWhite", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Input_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Category_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_42", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_42", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Add", "s-Image_42"]; 

	widgets.descriptionMap[["s-Image_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "07fabf3e-7610-40c2-b7d6-e4f6be34495e"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-BgWhite", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Paragraph_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Button_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "1904417b-d967-4d1f-a16b-0fa7d3f4ab3b"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "33ab7b75-f9e7-482d-a9b2-ce5932d708a4"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Category_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Category_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Category_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Custom Select List", "s-Category_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_5", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_6", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Category_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_4", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Custom Select List", "s-Category_4"]; 

	widgets.descriptionMap[["s-Image_42", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_42", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Add", "s-Image_42"]; 

	widgets.descriptionMap[["s-Button_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "9f360f30-0450-47f9-9b54-cb26dac0ccab"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_2", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_44", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_44", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Chevron Right", "s-Image_44"]; 

	widgets.descriptionMap[["s-Image_45", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_45", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Chevron Right", "s-Image_45"]; 

	widgets.descriptionMap[["s-Image_46", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_46", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Chevron Right", "s-Image_46"]; 

	widgets.descriptionMap[["s-Image_47", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_47", "b385e9eb-ecc9-48cb-8c57-9430219bc46f"]] = ["Chevron Right", "s-Image_47"]; 

	widgets.descriptionMap[["s-BgWhite", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Image_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image_44", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_44", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Chevron Right", "s-Image_44"]; 

	widgets.descriptionMap[["s-Image_45", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_45", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Chevron Right", "s-Image_45"]; 

	widgets.descriptionMap[["s-Image_46", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_46", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Chevron Right", "s-Image_46"]; 

	widgets.descriptionMap[["s-Paragraph_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Rectangle_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Image_47", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_47", "330edaa3-9581-4140-b862-9b0ca4ad4bbb"]] = ["Chevron Right", "s-Image_47"]; 

	widgets.descriptionMap[["s-BgWhite", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "4a272366-d80d-4203-9dd9-4b2c52fa0fd9"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rectangle_12", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_110", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Image_110", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Star", "s-Image_110"]; 

	widgets.descriptionMap[["s-Ellipse_9", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_15", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Ellipse_8", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_3", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_7", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_14", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_11", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_5", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Ellipse_4", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_5", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Ellipse_3", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_16", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Text_6", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Ellipse_2", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_13", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Text_7", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Ellipse_1", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_18", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-All", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-All", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Ellipse_23", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_23", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-Ellipse_24", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_24", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-plus_2", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-plus_2", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-Bg", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-Text", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-menu", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-hour", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "90cefbcd-3696-475d-ac62-da78822a86e3"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-BgWhite", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "4100fa47-e71a-4055-af5c-e07a7602f32c"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Bg", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-BgWhite_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Dark Background", "s-BgWhite_1"]; 

	widgets.descriptionMap[["s-Softkeys-bg_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys_1"]; 

	widgets.descriptionMap[["s-Square_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Square_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys_1"]; 

	widgets.descriptionMap[["s-Circle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys_1"]; 

	widgets.descriptionMap[["s-Triangle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys_1"]; 

	widgets.descriptionMap[["s-Black-cover_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Dark Background", "s-Black-cover_1"]; 

	widgets.descriptionMap[["s-Rectangle_115", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Navigation drawer", "s-Side-drawer_1"]; 

	widgets.descriptionMap[["s-Text_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Navigation drawer", "s-Side-drawer_1"]; 

	widgets.descriptionMap[["s-menu_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-menu_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Menu", "s-menu_1"]; 

	widgets.descriptionMap[["s-more-vertical_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["More Vertical", "s-more-vertical_1"]; 

	widgets.descriptionMap[["s-Search_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Search_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Search", "s-Search_1"]; 

	widgets.descriptionMap[["s-Share_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Share_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Share", "s-Share_1"]; 

	widgets.descriptionMap[["s-Bg_status_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-hour_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-hour_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-signals_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-signals_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_6", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Input_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_7", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Input_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Input Text Field", "s-Input_4"]; 

	widgets.descriptionMap[["s-Paragraph_8", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Input_5", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Input Text Field", "s-Input_5"]; 

	widgets.descriptionMap[["s-Button_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_9", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "58530efa-8638-4117-b3de-597bfaa5b18d"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Rectangle_12", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_110", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_110", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Star", "s-Image_110"]; 

	widgets.descriptionMap[["s-Ellipse_9", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_15", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Ellipse_8", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_3", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_7", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_14", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_11", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_5", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Ellipse_4", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_5", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Ellipse_3", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_16", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Ellipse_2", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_13", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Text_7", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Ellipse_1", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_18", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-All", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-All", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Bg", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-Text", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-menu", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-hour", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "7af17633-bc62-41c8-9704-cb5dd4bfd47e"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-BgWhite", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "0ee15278-8ef7-4452-abd6-e4b481ab1bd2"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rectangle", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Passcode lock screen", "s-Lock_screen_passcode"]; 

	widgets.descriptionMap[["s-Black-cover", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Signal-icon", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-Signal-icon", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Passcode lock screen", "s-Lock_screen_passcode"]; 

	widgets.descriptionMap[["s-Input_2", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-raised_Button_disabled", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-raised_Button_disabled", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Raised button disabled", "s-raised_Button_disabled"]; 

	widgets.descriptionMap[["s-Paragraph_1", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "56cbf5f8-f23f-4194-937c-aa6f212f9ce6"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-BgWhite", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Button_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Button_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "b7c8aafe-d3ec-4276-b600-0e61c2c875ce"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-BgWhite", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Rectangle_115", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Category_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Input_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Date", "s-Input_1"]; 

	widgets.descriptionMap[["s-Button_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_42", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ""; 

			widgets.rootWidgetMap[["s-Image_42", "c627577d-db87-4fc1-bc52-7ff58e0e1947"]] = ["Add", "s-Image_42"]; 

	widgets.descriptionMap[["s-BgWhite", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Category_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "662f1b93-c984-4f38-aec3-d25f79556bd9"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Screen-bg", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Screen-bg", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Dark Background", "s-Screen-bg"]; 

	widgets.descriptionMap[["s-Softkeys-bg_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Square_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Square_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Circle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Triangle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Bg_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-more-vertical_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["More Vertical", "s-more-vertical_1"]; 

	widgets.descriptionMap[["s-menu_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-menu_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Menu", "s-menu_1"]; 

	widgets.descriptionMap[["s-Text_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Bg_status_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-hour_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-hour_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-signals_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-signals_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Status bar light", "s-Status-bar_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_45", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_45", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_45"]; 

	widgets.descriptionMap[["s-Paragraph_3", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_46", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_46", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_46"]; 

	widgets.descriptionMap[["s-Paragraph_4", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_47", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_47", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_47"]; 

	widgets.descriptionMap[["s-Rectangle_5", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Paragraph_5", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Image_48", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_48", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_48"]; 

	widgets.descriptionMap[["s-Rectangle_6", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_44", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_44", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_44"]; 

	widgets.descriptionMap[["s-Image_37", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Home", "s-Image_37"]; 

	widgets.descriptionMap[["s-Paragraph_6", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_49", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_49", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_49"]; 

	widgets.descriptionMap[["s-Paragraph_7", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Image_50", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_50", "9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6"]] = ["Chevron Right", "s-Image_50"]; 

	widgets.descriptionMap[["s-BgWhite", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Category_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "311d36d6-d425-4a4a-b565-383c0993b00d"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_12", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_110", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Image_110", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Star", "s-Image_110"]; 

	widgets.descriptionMap[["s-Ellipse_9", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_15", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Ellipse_8", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_3", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_7", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_14", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_11", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_5", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Ellipse_4", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_5", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Ellipse_3", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_16", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Ellipse_2", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_8"]; 

	widgets.descriptionMap[["s-Rectangle_13", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Text_7", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Ellipse_1", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["oneline complete", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_18", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-All", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-All", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Bg", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-Text", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-menu", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-hour", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "3cd31e95-4337-4cbf-abaf-fd1a5e4971a6"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-BgWhite", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Paragraph_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Account Circle", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Category_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "3fca400d-1926-4a4e-8303-0e864a3c899f"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Paragraph_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle_2", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Category_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "92ac0fa0-383d-469b-9900-a1491e953075"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Bg", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Lock screen", "s-Lock_screen"]; 

	widgets.descriptionMap[["s-Signals", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Signals", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Lock screen", "s-Lock_screen"]; 

	widgets.descriptionMap[["s-Paragraph_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Button_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "95fed0f1-464f-49cf-b9d9-f69d3c711405"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-BgWhite", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Input_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Image_42", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Image_42", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Add", "s-Image_42"]; 

	widgets.descriptionMap[["s-Button_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "08b6b339-1d54-4130-afa9-720df9972c35"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Rectangle_12", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Image_110", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_110", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Star", "s-Image_110"]; 

	widgets.descriptionMap[["s-Ellipse_9", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_9", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Contact list item", "s-Group_4"]; 

	widgets.descriptionMap[["s-Rectangle_15", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Ellipse_8", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_8", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_7"]; 

	widgets.descriptionMap[["s-Rectangle_3", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_7", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_7", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_2"]; 

	widgets.descriptionMap[["s-Rectangle_14", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Ellipse_6", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_6", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_6"]; 

	widgets.descriptionMap[["s-Rectangle_11", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_4", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Text_4", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Ellipse_5", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_5", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_17", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Ellipse_4", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Text_5", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Ellipse_3", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["oneline complete", "s-Group_5"]; 

	widgets.descriptionMap[["s-Rectangle_18", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-All", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-All", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["one line dialog", "s-inbox-dinamicpanel"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Ellipse_23", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_23", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-Ellipse_24", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_24", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-plus_2", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-plus_2", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["FAB", "s-Float-button-plus"]; 

	widgets.descriptionMap[["s-Bg", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-Text", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Top bar 2 icons", "s-Title-bar"]; 

	widgets.descriptionMap[["s-menu", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-hour", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "a8ce95c9-b132-437d-b7bf-5ba4b4a313c8"]] = ["Status bar dark", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Lock screen", "s-Lock_screen"]; 

	widgets.descriptionMap[["s-Signals", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Signals", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Lock screen", "s-Lock_screen"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-flat_Button_lightTheme", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-flat_Button_lightTheme", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Flat button light theme", "s-flat_Button_lightTheme"]; 

	widgets.descriptionMap[["s-flat_Button_darkTheme", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-flat_Button_darkTheme", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Flat button dark theme", "s-flat_Button_darkTheme"]; 

	widgets.descriptionMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-BgWhite", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Image_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "1e637558-86bf-4ac2-a195-9da821046d78"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-BgWhite", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-BgWhite", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Dark Background", "s-BgWhite"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Square", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Circle", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Triangle", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Horizontal softkeys", "s-Horizontal_softkeys"]; 

	widgets.descriptionMap[["s-Black-cover", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Black-cover", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Dark Background", "s-Black-cover"]; 

	widgets.descriptionMap[["s-Rectangle_115", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_115", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg_status_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Ellipse_4", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-drop-down_3", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-drop-down_3", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Drop Down", "s-drop-down_3"]; 

	widgets.descriptionMap[["s-Label_60", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Label_60", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Label_61", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Label_61", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Two-line-item_27", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_27", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_27"]; 

	widgets.descriptionMap[["s-Two-line-item_22", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_22", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_22"]; 

	widgets.descriptionMap[["s-Two-line-item_24", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_24", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_24"]; 

	widgets.descriptionMap[["s-Image_16", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Two-line-item_34", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_34", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_34"]; 

	widgets.descriptionMap[["s-Image_74", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Two-line-item_12", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_12", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_12"]; 

	widgets.descriptionMap[["s-Image_103", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_103", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Star", "s-Image_103"]; 

	widgets.descriptionMap[["s-Two-line-item_23", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_23", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_23"]; 

	widgets.descriptionMap[["s-Image_29", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_29", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Favorite", "s-Image_29"]; 

	widgets.descriptionMap[["s-Two-line-item_28", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_28", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_28"]; 

	widgets.descriptionMap[["s-Image_140", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Clock", "s-Image_140"]; 

	widgets.descriptionMap[["s-Two-line-item_29", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_29", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_29"]; 

	widgets.descriptionMap[["s-Image_3", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["File Upload", "s-Image_3"]; 

	widgets.descriptionMap[["s-Two-line-item_30", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_30", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_30"]; 

	widgets.descriptionMap[["s-Image_6", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Cloud Upload", "s-Image_6"]; 

	widgets.descriptionMap[["s-Two-line-item_41", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_41", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_41"]; 

	widgets.descriptionMap[["s-Two-line-item_43", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_43", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_43"]; 

	widgets.descriptionMap[["s-Image_18", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Delete", "s-Image_18"]; 

	widgets.descriptionMap[["s-Two-line-item_42", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_42", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_42"]; 

	widgets.descriptionMap[["s-Two-line-item_44", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Two-line-item_44", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Two line item", "s-Two-line-item_44"]; 

	widgets.descriptionMap[["s-Image_22", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Settings", "s-Image_22"]; 

	widgets.descriptionMap[["s-Panel_7", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_7", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share menu dialog", "s-side-drawer-dialog"]; 

	widgets.descriptionMap[["s-Bg", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-Text", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Navigation drawer", "s-Side-drawer"]; 

	widgets.descriptionMap[["s-menu", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-menu", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Menu", "s-menu"]; 

	widgets.descriptionMap[["s-more-vertical", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Search", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Search", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Search", "s-Search"]; 

	widgets.descriptionMap[["s-Share", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Share", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Share", "s-Share"]; 

	widgets.descriptionMap[["s-Bg_status", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-signals", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-signals", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Rectangle_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Category_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Custom Select List", "s-Category_1"]; 

	widgets.descriptionMap[["s-Button_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Image_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "ba50421d-0619-44ae-b061-b5ee98f45737"]] = ["Image", "s-Image_1"]; 

	