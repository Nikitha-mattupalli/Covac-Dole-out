document.write("<script type='text/javascript' charset='utf-8' src='./resources/jim/javascript/jim-multi-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/widgets/widgets-description.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scenarios/function-jim-links1619920256764.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scroll-1619920256764.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/prototype-1619920256764.js'></script>");