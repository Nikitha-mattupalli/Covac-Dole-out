var content='<div class="ui-page" deviceName="iphonex" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="corporate mainpage" width="375" height="812">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9ee776e1-89b4-4dcc-a3c6-aea72fef8cf6-1619920256764-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Empty_screen" class="group firer ie-background commentable non-processed" customid="Empty_screen" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Screen-bg" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Screen-bg"   datasizewidth="100.0%" datasizeheight="100.0%" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Softkeys-bg_1" class="pie percentage rectangle manualfit firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed" customid="Softkeys-bg"   datasizewidth="100.0%" datasizeheight="48.0px" datasizewidthpx="375.0" datasizeheightpx="48.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Softkeys-bg_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Square_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed" customid="Square"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="74.0" dataY="17.0" aspectRatio="1.0"   alt="image" systemName="./images/f8e887c0-08b1-41a8-aae0-87cd004f2ea7.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
            	    <title>recent</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Square_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
            	            <g id="s-Square_1-Group-3" transform="translate(231.000000, 0.000000)">\
            	                <rect id="s-Square_1-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Circle_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Circle"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="0.0" dataY="15.0" aspectRatio="1.0"   alt="image" systemName="./images/77983e38-309a-4e89-8416-a8422c91ef3f.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
            	    <title>home</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Circle_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
            	            <g id="s-Circle_1-Group-4" transform="translate(130.000000, 0.000000)">\
            	                <g id="s-Circle_1-home" transform="translate(40.000000, 14.000000)">\
            	                    <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
            	                    <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Triangle_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Triangle"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="76.0" dataY="17.0" aspectRatio="1.0"   alt="image" systemName="./images/286a7b55-53a9-439e-a1ca-e65936eb9751.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
            	    <title>back</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Triangle_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
            	            <g id="s-Triangle_1-Group-2" transform="translate(29.000000, 0.000000)">\
            	                <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle_1-back"></path>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Bg_1" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg"   datasizewidth="100.0%" datasizeheight="76.0px" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="more-vertical"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="8.0" dataY="36.0"   alt="image" systemName="./images/0cc4f1cd-5bee-4c5c-aca8-73ff459a6e3e.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-menu_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="menu"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="13.0" dataY="36.0"   alt="image" systemName="./images/5f4dfa43-c110-4f5d-b0a1-9f6ba78962a9.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Text"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="68.0" dataY="36.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Status-bar_1" class="group firer ie-background commentable non-processed" customid="Status-bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_status_2" class="pie percentage rectangle manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg_status"   datasizewidth="100.0%" datasizeheight="20.0px" datasizewidthpx="375.0" datasizeheightpx="20.0" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_status_2_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-hour_1" class="pie richtext manualfit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="hour"   datasizewidth="46.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-hour_1_0">15:45</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-signals_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="signals"   datasizewidth="61.0px" datasizeheight="20.0px" dataX="8.0" dataY="0.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/a483ed1f-1e5d-4647-96e2-4344694e7974.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.5px" datasizeheight="62.3px" datasizewidthpx="308.49999999999966" datasizeheightpx="62.29166666666643" dataX="33.0" dataY="216.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.5px" datasizeheight="64.4px" datasizewidthpx="308.50000000000045" datasizeheightpx="64.37499999999989" dataX="33.0" dataY="302.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_4" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle"   datasizewidth="307.8px" datasizeheight="63.5px" datasizewidthpx="307.75000000000057" datasizeheightpx="63.500000000000114" dataX="33.0" dataY="386.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="218.7px" datasizeheight="27.0px" dataX="69.0" dataY="231.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">LAND TRANSPORT</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_45" class="pie image firer click ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="301.0" dataY="232.0"   alt="image" systemName="./images/e2a3d3de-d947-4a52-b8c0-99b004d2f2ce.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_3" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="231.2px" datasizeheight="24.0px" dataX="63.0" dataY="324.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">HEALTH CARE CAMPS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_46" class="pie image firer click ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="301.0" dataY="324.0"   alt="image" systemName="./images/6db579b6-b0fe-4457-854f-6cb16a60fb69.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_4" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="100.0px" datasizeheight="27.0px" dataX="96.0" dataY="404.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">TRIBALS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_47" class="pie image firer click ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="301.0" dataY="406.0"   alt="image" systemName="./images/22461d2b-f8c5-4f8d-a69e-1142e9cacebb.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_5" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle"   datasizewidth="309.1px" datasizeheight="63.3px" datasizewidthpx="309.125" datasizeheightpx="63.33333333333326" dataX="33.0" dataY="472.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="194.7px" datasizeheight="27.0px" dataX="63.0" dataY="490.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">AIR TRANSPORT</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_48" class="pie image firer click ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="301.0" dataY="491.5"   alt="image" systemName="./images/909f8b4b-81d5-433c-8a79-3313ad309f76.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="57.1px" datasizewidthpx="307.9687500000002" datasizeheightpx="57.08333333333326" dataX="33.0" dataY="557.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.5px" datasizeheight="64.0px" datasizewidthpx="308.4999999999998" datasizeheightpx="63.999999999999886" dataX="33.3" dataY="128.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="190.7px" datasizeheight="27.0px" dataX="76.0" dataY="146.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">COLD STORAGE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_44" class="pie image firer click ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="305.7" dataY="148.0"   alt="image" systemName="./images/2503bb98-1cb2-40c1-941c-db5346da66ba.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_37" class="pie image firer click ie-background commentable non-processed" customid="Image_36"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="317.8" dataY="36.5"   alt="image" systemName="./images/5235b4ef-4364-4673-8c14-413c7d6fc2ff.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="157.7px" datasizeheight="24.0px" dataX="61.0" dataY="574.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">COLLABORATE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_49" class="pie image firer ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="305.7" dataY="574.0"   alt="image" systemName="./images/8c54c36f-f838-483b-a4ac-b7c257b1603c.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle 7"   datasizewidth="308.5px" datasizeheight="63.5px" datasizewidthpx="308.4999999999994" datasizeheightpx="63.45833333333337" dataX="33.3" dataY="639.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="262.0px" datasizeheight="19.0px" dataX="56.5" dataY="661.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">PORTABLE VACCINE CENTERS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_50" class="pie image firer ie-background commentable non-processed" customid="Image_44"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="317.8" dataY="658.7"   alt="image" systemName="./images/24268323-11f4-47f4-a657-18ee6802fbad.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;