var content='<div class="ui-page" deviceName="iphonex" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-56cbf5f8-f23f-4194-937c-aa6f212f9ce6" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="login-corporate" width="375" height="812">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/56cbf5f8-f23f-4194-937c-aa6f212f9ce6-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/56cbf5f8-f23f-4194-937c-aa6f212f9ce6-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/56cbf5f8-f23f-4194-937c-aa6f212f9ce6-1619920256764-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Lock_screen_passcode" class="group firer ie-background commentable non-processed" customid="Lock_screen_passcode" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle" class="pie percentage rectangle manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Rectangle"   datasizewidth="100.0%" datasizeheight="100.0%" datasizewidthpx="375.0" datasizeheightpx="811.9999999999999" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Black-cover" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin hidden non-processed" customid="Black-cover"   datasizewidth="100.0%" datasizeheight="100.0%" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Black-cover_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Signal-icon" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Signal-icon"   datasizewidth="61.0px" datasizeheight="20.0px" dataX="8.0" dataY="0.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/b9630922-0b85-4da2-aee7-39d7c54fd541.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Input_2" class="pie password firer commentable non-processed" customid="Input"  datasizewidth="285.6px" datasizeheight="53.0px" dataX="36.0" dataY="390.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="PASSWORD"/></div></div></div></div></div>\
      </div>\
\
      <div id="s-raised_Button_disabled" class="pie button multiline manualfit firer click commentable non-processed" customid="raised_Button_disabled"   datasizewidth="107.0px" datasizeheight="36.0px" dataX="126.5" dataY="518.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-raised_Button_disabled_0">LOGIN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie percentage text firer commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_3"  datasizewidth="77.8%" datasizeheight="44.0px" dataX="-0.0" dataY="320.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="EMAIL"/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="207.5px" datasizeheight="76.0px" dataX="83.8" dataY="118.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">LOGIN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;