var content='<div class="ui-page" deviceName="iphonex" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-4a272366-d80d-4203-9dd9-4b2c52fa0fd9" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="coldstorage" width="375" height="812">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4a272366-d80d-4203-9dd9-4b2c52fa0fd9-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4a272366-d80d-4203-9dd9-4b2c52fa0fd9-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4a272366-d80d-4203-9dd9-4b2c52fa0fd9-1619920256764-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Side-drawer" class="group firer ie-background commentable non-processed" customid="Side-drawer" datasizewidth="305.0px" datasizeheight="592.0px" >\
        <div id="s-BgWhite" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="BgWhite"   datasizewidth="100.0%" datasizeheight="100.0%" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-BgWhite_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Horizontal_softkeys" class="group firer ie-background commentable non-processed" customid="Horizontal_softkeys" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Softkeys-bg" class="pie percentage rectangle manualfit firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed" customid="Softkeys-bg"   datasizewidth="100.0%" datasizeheight="48.0px" datasizewidthpx="375.0" datasizeheightpx="48.0" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Softkeys-bg_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed" customid="Square"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="74.0" dataY="17.0" aspectRatio="1.0"   alt="image" systemName="./images/85865172-1676-4a30-b248-4d311bf70378.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>recent</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
              	            <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
              	                <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Circle"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="0.0" dataY="15.0" aspectRatio="1.0"   alt="image" systemName="./images/c200cfcb-db8e-4cf5-9f75-50a9b4f2f597.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>home</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
              	            <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
              	                <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
              	                    <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
              	                    <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Triangle" class="pie image lockV firer click ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Triangle"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="76.0" dataY="17.0" aspectRatio="1.0"   alt="image" systemName="./images/b9d1340a-9f6d-4401-bb05-d2d5cdf50096.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>back</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
              	            <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
              	                <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
        <div id="s-Black-cover" class="pie percentage richtext manualfit firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin hidden non-processed" customid="Black-cover"   datasizewidth="100.0%" datasizeheight="100.0%" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Black-cover_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-side-drawer-dialog" class="pie percentage dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin hidden non-processed" customid="side-drawer-dialog" datasizewidth="305.0px" datasizeheight="100.0%" dataX="-305.0" dataY="0.0" >\
          <div id="s-Panel_7" class="pie percentage panel default firer commentable non-processed-percentage non-processed" customid="Panel_7"  datasizewidth="305.0px" datasizeheight="100.0%" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
            	<div class="layoutWrapper scrollable">\
            	  <div class="paddingLayer">\
                  <table class="layout" summary="">\
                    <tr>\
                      <td class="layout vertical insertionpoint verticalalign Panel_7 side-drawer-dialog" valign="top" align="left" hSpacing="0" vSpacing="0"><div class="relativeLayoutWrapper s-side-drawer-header_1 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-side-drawer-header_1" class="group firer ie-background commentable non-processed" customid="side-drawer-header_1" datasizewidth="306.0px" datasizeheight="175.0px" >\
                    <div id="s-Rectangle_115" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_115"   datasizewidth="306.0px" datasizeheight="175.0px" datasizewidthpx="306.0" datasizeheightpx="175.0" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_115_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Bg_status_1" class="pie percentage rectangle manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg_status_1"   datasizewidth="100.0%" datasizeheight="20.0px" datasizewidthpx="305.0" datasizeheightpx="20.0" dataX="0.0" dataY="0.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Bg_status_1_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="50.0px" datasizeheight="50.0px" datasizewidthpx="50.0" datasizeheightpx="50.0" dataX="17.0" dataY="40.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_4)">\
                                        <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                                        <ellipse cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_4" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_4_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
\
                    <div id="s-drop-down_3" class="pie image firer ie-background commentable non-processed" customid="drop-down_3"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="263.0" dataY="132.0"   alt="image" systemName="./images/fd85d7e6-29a8-4faa-813b-9d9b07beb4fa.svg" overlay="#55585A">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 10l5 5 5-5z" fill="#55585A" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Label_60" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Label_60"   datasizewidth="244.0px" datasizeheight="24.0px" dataX="18.0" dataY="134.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Label_60_0">corporate@mail.com</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Label_61" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Label_61"   datasizewidth="237.0px" datasizeheight="33.0px" dataX="18.0" dataY="104.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Label_61_0">CORPORATE1</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  </div></div><div id="s-Two-line-item_27" class="pie rectangle manualfit firer commentable non-processed" customid="Two-line-item_27"   datasizewidth="306.0px" datasizeheight="10.0px" datasizewidthpx="306.0" datasizeheightpx="10.0" dataX="0.0" dataY="175.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Two-line-item_27_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div><div class="relativeLayoutWrapper s-Share-palette_6 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_6" class="group firer ie-background commentable non-processed" customid="Share-palette_6" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_22" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Two-line-item_22"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="185.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_22_0"></span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Two-line-item_24" class="pie rectangle manualfit firer commentable non-processed" customid="Two-line-item_24"   datasizewidth="286.0px" datasizeheight="40.0px" datasizewidthpx="286.0" datasizeheightpx="40.0" dataX="9.0" dataY="188.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_24_0">MY PROFILE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_16" class="pie image firer ie-background commentable non-processed" customid="Image_16"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="196.0"   alt="image" systemName="./images/1c9eb164-d6bf-4986-8c8c-6cc41f4d25e6.svg" overlay="#FFFFFF">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" fill="#FFFFFF" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_16 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_16" class="group firer ie-background commentable non-processed" customid="Share-palette_16" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_34" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_34"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="231.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_34_0">COLD STORAGE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_74" class="pie image firer ie-background commentable non-processed" customid="Image_74"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="242.0"   alt="image" systemName="./images/1f0b1860-2876-46a8-a500-74fe908db00c.svg" overlay="#1BDAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" fill="#1BDAF1" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_2 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_2" class="group firer ie-background commentable non-processed" customid="Share-palette_2" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_12" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_12"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="277.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_12_0">TRANSPORT</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_103" class="pie image firer ie-background commentable non-processed" customid="Image_103"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="288.0"   alt="image" systemName="./images/ff3d9245-5f41-4254-b9d3-fc73d113bac0.svg" overlay="#1EAAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M4 16c0 .88.39 1.67 1 2.22V20c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10zm3.5 1c-.83 0-1.5-.67-1.5-1.5S6.67 14 7.5 14s1.5.67 1.5 1.5S8.33 17 7.5 17zm9 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm1.5-6H6V6h12v5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_14 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_14" class="group firer ie-background commentable non-processed" customid="Share-palette_14" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_23" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_23"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="323.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_23_0">AIR TRANSPORT</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_29" class="pie image firer ie-background commentable non-processed" customid="Image_29"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="334.0"   alt="image" systemName="./images/524a6205-fa68-4a20-b427-8942f3b5c132.svg" overlay="#1BDAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M10.18 9" fill="#1BDAF1" jimofill=" " /><path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" fill="#1BDAF1" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_15 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_15" class="group firer ie-background commentable non-processed" customid="Share-palette_15" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_28" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_28"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="369.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_28_0">HEALTH CARE CAMPS</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_140" class="pie image firer ie-background commentable non-processed" customid="Image_140"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="380.0"   alt="image" systemName="./images/d349b577-9968-447f-93b4-1c1f8ed081fe.svg" overlay="#1EAAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 20010904//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd"><svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="500.000000pt" preserveAspectRatio="xMidYMid meet" version="1.0" viewBox="0 0 500.000000 500.000000" width="500.000000pt">\
\
                        	<g fill="#000000" stroke="none" transform="translate(0.000000,500.000000) scale(0.100000,-0.100000)">\
                        	<path d="M573 4988 c-28 -13 -49 -63 -37 -87 9 -18 310 -370 444 -518 36 -40 94 -106 129 -148 l63 -76 -25 -27 c-43 -47 -61 -93 -61 -157 0 -77 12 -98 130 -235 l96 -111 -55 -52 c-58 -54 -77 -97 -77 -167 1 -72 47 -140 217 -319 29 -30 53 -58 53 -63 0 -4 32 -44 71 -88 l71 -80 -16 -34 c-12 -26 -16 -66 -16 -171 0 -185 11 -205 118 -205 l42 0 0 -86 0 -86 -78 -92 c-90 -105 -172 -205 -222 -270 -19 -25 -40 -46 -46 -46 -13 0 -305 339 -335 389 -14 24 -19 51 -19 111 l0 80 50 0 c41 0 56 5 75 25 24 24 25 28 25 183 0 153 -1 159 -23 180 -23 22 -26 22 -420 22 -384 0 -398 -1 -417 -20 -18 -18 -20 -33 -20 -180 0 -157 1 -161 25 -185 20 -21 34 -25 80 -25 l55 0 0 -81 0 -81 -125 -152 c-68 -83 -151 -183 -183 -221 -112 -133 -125 -186 -120 -498 3 -185 5 -207 22 -226 25 -27 79 -28 106 -1 17 17 20 33 20 120 l0 100 565 0 565 0 0 -345 0 -345 -565 0 -565 0 0 71 c0 39 -5 79 -11 90 -15 29 -52 40 -89 28 -48 -17 -52 -48 -48 -394 3 -350 6 -362 84 -437 78 -74 64 -73 583 -76 517 -3 572 1 639 48 l43 30 44 -30 c24 -16 66 -35 93 -41 33 -7 215 -9 529 -7 l479 3 59 30 c67 35 113 86 126 141 4 22 9 343 9 713 l0 675 83 -90 c109 -116 167 -184 166 -192 0 -4 -37 -38 -81 -77 -133 -114 -155 -194 -88 -311 35 -61 103 -110 166 -120 64 -9 123 11 176 59 72 68 241 212 268 229 14 9 76 64 138 122 62 58 117 106 121 106 4 0 51 -51 104 -112 53 -62 117 -133 142 -157 25 -25 45 -48 45 -53 0 -10 279 -331 296 -341 8 -4 14 -12 14 -17 0 -5 -57 -59 -127 -120 -157 -137 -173 -161 -173 -256 0 -61 4 -76 29 -117 35 -54 88 -91 153 -107 79 -20 139 4 234 96 43 42 95 86 114 99 95 63 455 400 471 442 18 46 13 135 -9 180 -49 95 -150 146 -245 124 -57 -13 -84 -32 -207 -140 -47 -41 -95 -84 -107 -94 l-21 -19 -129 148 c-70 82 -154 175 -187 209 -32 33 -77 85 -99 115 -22 30 -68 87 -102 125 -33 39 -66 77 -73 86 -11 15 -2 24 63 74 86 64 104 92 87 129 -15 34 -56 59 -82 51 -12 -4 -60 -41 -108 -82 -47 -41 -110 -93 -139 -115 -29 -21 -53 -42 -53 -46 0 -4 -89 -83 -196 -177 -108 -93 -228 -198 -266 -232 -84 -76 -120 -83 -162 -32 -43 51 -35 76 45 143 39 33 108 94 153 137 124 117 217 199 256 224 19 12 80 65 135 117 55 52 156 142 225 201 146 124 164 140 288 253 73 65 100 84 123 84 35 0 75 -36 85 -74 9 -36 -13 -65 -96 -133 -59 -49 -70 -62 -70 -88 0 -38 35 -75 71 -75 29 0 185 127 214 173 24 39 24 161 0 208 -42 84 -118 133 -205 133 -70 0 -116 -24 -197 -103 -34 -34 -66 -61 -71 -61 -5 0 -36 30 -68 67 -33 37 -101 113 -152 168 -52 55 -104 116 -117 135 -22 34 -142 172 -243 280 -29 30 -82 92 -119 138 -69 84 -96 115 -343 395 -77 87 -140 161 -140 165 0 4 -29 39 -65 77 -36 39 -128 141 -203 229 -330 382 -345 395 -449 396 -66 0 -95 -11 -152 -59 l-46 -39 -100 116 c-77 89 -111 120 -150 138 -78 37 -152 29 -222 -22 -31 -24 -32 -24 -46 -4 -7 11 -51 59 -97 107 -45 48 -101 112 -123 142 -47 63 -151 185 -246 286 -36 39 -91 98 -122 133 -57 63 -68 69 -106 50z m941 -861 c28 -29 75 -80 104 -114 l53 -61 -108 -96 c-59 -53 -114 -103 -121 -112 -8 -8 -17 -14 -21 -12 -5 2 -49 50 -99 108 -121 138 -121 142 -9 243 86 77 112 96 136 97 8 0 38 -24 65 -53z m516 -147 c15 -11 56 -51 90 -90 l62 -70 -56 -50 c-30 -28 -58 -60 -61 -70 -9 -28 21 -79 51 -86 33 -8 58 4 116 55 l47 42 24 -38 c13 -21 50 -64 81 -95 31 -32 56 -61 56 -65 0 -3 -50 -54 -111 -111 -104 -99 -110 -107 -107 -140 4 -46 46 -81 80 -65 13 6 72 54 133 107 84 74 112 93 121 83 89 -99 154 -180 154 -191 0 -17 -17 -35 -66 -72 -44 -34 -47 -82 -8 -113 15 -12 34 -21 43 -21 10 0 43 23 74 51 32 28 59 50 61 48 2 -2 43 -49 90 -104 l87 -100 -63 -58 c-35 -32 -89 -79 -120 -104 -42 -33 -58 -53 -58 -70 0 -36 15 -59 49 -72 35 -15 54 -7 115 48 23 21 71 61 107 89 l67 51 107 -122 107 -122 -29 -23 c-15 -13 -70 -63 -122 -110 -51 -48 -101 -91 -110 -96 -21 -12 -242 -207 -349 -309 -46 -44 -87 -75 -91 -71 -5 5 -76 89 -160 187 l-151 177 0 85 0 85 44 0 c106 0 120 28 115 234 -5 192 27 176 -359 176 l-307 0 -79 92 c-44 51 -111 127 -150 168 -39 41 -91 102 -117 135 -25 33 -60 76 -76 95 -22 25 -31 46 -31 71 0 38 1 40 106 129 16 14 123 108 238 210 115 102 224 197 244 213 42 32 74 34 112 7z m-997 -1280 c3 -11 3 -38 0 -60 l-6 -40 -298 0 -299 0 0 53 c0 30 3 57 7 60 3 4 138 7 299 7 283 0 292 -1 297 -20z m1267 -40 l0 -60 -295 0 -295 0 0 60 0 60 295 0 295 0 0 -60z m-1430 -275 l0 -66 -137 3 -138 3 -3 63 -3 62 141 0 140 0 0 -65z m1280 0 l0 -65 -140 0 -140 0 0 65 0 65 140 0 140 0 0 -65z m1288 -15 c17 -21 32 -42 32 -47 0 -4 -15 -18 -33 -29 -38 -26 -192 -159 -337 -295 -58 -53 -133 -119 -167 -146 -34 -26 -84 -67 -111 -90 l-50 -43 -36 41 c-21 22 -35 46 -33 52 2 7 33 35 69 62 78 60 278 234 368 321 36 34 99 89 140 121 41 33 81 67 89 76 20 25 32 21 69 -23z m232 -270 l99 -115 -37 -33 c-20 -18 -59 -50 -87 -71 -27 -21 -76 -64 -108 -95 l-59 -57 -41 48 c-23 26 -55 62 -72 79 -16 18 -45 48 -63 67 l-34 35 134 117 c73 64 137 124 141 132 5 8 13 13 18 11 5 -2 54 -55 109 -118z m-2707 28 c29 -35 72 -88 94 -119 23 -31 77 -94 120 -141 99 -107 115 -140 121 -245 l5 -83 -567 0 -566 0 0 62 c0 107 25 172 95 247 34 36 114 128 178 204 l118 137 173 0 174 0 55 -62z m1274 -7 c32 -39 77 -94 101 -123 23 -29 74 -87 113 -128 39 -41 80 -92 91 -113 24 -47 40 -140 32 -185 l-6 -32 -562 2 -561 3 3 89 c1 53 8 101 17 120 9 18 53 73 98 123 46 50 125 141 177 202 l93 111 173 0 173 0 58 -69z m1027 -367 c53 -61 96 -115 96 -120 0 -5 -46 -47 -101 -94 -56 -47 -119 -102 -142 -122 l-41 -37 -61 63 c-33 34 -79 85 -103 113 l-42 51 122 109 c68 59 131 118 142 131 10 13 22 22 26 20 4 -2 51 -53 104 -114z m-694 -689 l0 -345 -560 0 -560 0 0 345 0 345 560 0 560 0 0 -345z m2243 -295 c38 -67 37 -68 -213 -283 -91 -78 -199 -173 -241 -212 -145 -133 -182 -149 -233 -99 -32 33 -34 74 -3 107 12 13 76 72 142 129 66 58 131 118 145 133 14 15 52 48 85 73 33 25 97 79 143 120 74 65 87 73 119 70 28 -2 39 -10 56 -38z m-3513 -368 c0 -194 -3 -208 -60 -237 -25 -13 -103 -15 -516 -15 l-486 0 -34 34 -34 34 0 181 0 181 565 0 565 0 0 -178z m1270 -5 l0 -183 -31 -30 -30 -29 -499 -3 -498 -3 -30 26 c-26 22 -31 35 -37 90 -4 36 -4 122 0 190 l7 125 559 0 559 0 0 -183z" style="fill:#1EAAF1 !important;" />\
                        	<path d="M1706 1088 c-21 -30 -20 -71 2 -91 16 -15 52 -17 300 -17 279 0 281 0 296 22 21 30 20 71 -2 91 -16 15 -52 17 -300 17 -279 0 -281 0 -296 -22z" style="fill:#1EAAF1 !important;" />\
                        	<path d="M444 1102 c-37 -24 -39 -93 -4 -112 24 -13 570 -13 590 0 10 6 15 25 15 55 0 30 -5 49 -15 55 -18 11 -570 13 -586 2z" style="fill:#1EAAF1 !important;" />\
                        	</g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_19 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_19" class="group firer ie-background commentable non-processed" customid="Share-palette_19" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_29" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_29"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="415.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_29_0">TRIBALS</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="426.0"   alt="image" systemName="./images/a740d5c4-c811-47f5-aa9c-4c3bb36b416c.svg" overlay="#1BDAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z" fill="#1BDAF1" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div class="relativeLayoutWrapper s-Share-palette_20 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_20" class="group firer ie-background commentable non-processed" customid="Share-palette_20" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_30" class="pie rectangle manualfit firer commentable non-processed" customid="Two-line-item_30"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="461.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_30_0">COLLABORATE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_6" class="pie image firer ie-background commentable non-processed" customid="Image_6"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="472.0"   alt="image" systemName="./images/f6ba539f-c81b-4e48-bde3-7c4bbc0f7f43.svg" overlay="#1EAAF1">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M17 20.41L18.41 19 15 15.59 13.59 17 17 20.41zM7.5 8H11v5.59L5.59 19 7 20.41l6-6V8h3.5L12 3.5 7.5 8z" fill="#1EAAF1" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div id="s-Two-line-item_41" class="pie rectangle manualfit firer commentable non-processed" customid="Two-line-item_41"   datasizewidth="306.0px" datasizeheight="20.0px" datasizewidthpx="306.0" datasizeheightpx="20.0" dataX="0.0" dataY="553.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Two-line-item_41_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div><div class="relativeLayoutWrapper s-Share-palette_17 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_17" class="group firer ie-background commentable non-processed" customid="Share-palette_17" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_43" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_43"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="507.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_43_0">BACK TO HOME PAGE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_18" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="518.0"   alt="image" systemName="./images/d1fc80b4-212c-4198-9733-3341454517ef.svg" overlay="#7F8383">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" fill="#7F8383" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div><div id="s-Two-line-item_42" class="pie rectangle manualfit firer commentable non-processed" customid="Two-line-item_42"   datasizewidth="306.0px" datasizeheight="13.0px" datasizewidthpx="306.0" datasizeheightpx="13.0" dataX="0.0" dataY="573.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Two-line-item_42_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div><div class="relativeLayoutWrapper s-Share-palette_18 "><div class="relativeLayoutWrapperResponsive">\
                  <div id="s-Share-palette_18" class="group firer ie-background commentable non-processed" customid="Share-palette_18" datasizewidth="306.0px" datasizeheight="46.0px" >\
                    <div id="s-Two-line-item_44" class="pie rectangle manualfit firer click commentable non-processed" customid="Two-line-item_44"   datasizewidth="306.0px" datasizeheight="46.0px" datasizewidthpx="306.0" datasizeheightpx="46.0" dataX="0.0" dataY="586.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Two-line-item_44_0">LOGIN PAGE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_22" class="pie image firer ie-background commentable non-processed" customid="Image_22"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="17.0" dataY="597.0"   alt="image" systemName="./images/b23e3659-9acd-4c7c-8e0f-a7357a2fa703.svg" overlay="#7F8383">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z" fill="#7F8383" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                  </div>\
                  </div></div></td> \
                    </tr>\
                  </table>\
\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg"   datasizewidth="100.0%" datasizeheight="76.0px" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text" class="pie richtext autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Text"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="68.0" dataY="36.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-menu" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="menu"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="13.0" dataY="36.0"   alt="image" systemName="./images/8a70d442-07a1-4964-b4cd-4c507a121edd.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="more-vertical"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="8.0" dataY="36.0"   alt="image" systemName="./images/75df095f-4a64-4f65-a6ee-c5e01884c1ef.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Search" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Search"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="43.0" dataY="37.0"   alt="image" systemName="./images/d9465ede-ed9d-4674-a98c-1454ea3e0f04.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Share" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Share"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="85.0" dataY="37.0"   alt="image" systemName="./images/efe2307a-98d0-41a3-99cf-ce1c04ce536c.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z" fill="#FFFFFF" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" customid="Status-bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg_status" class="pie percentage rectangle manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg_status"   datasizewidth="100.0%" datasizeheight="20.0px" datasizewidthpx="375.0" datasizeheightpx="20.0" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_status_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-hour" class="pie richtext manualfit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="hour"   datasizewidth="46.0px" datasizeheight="20.0px" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-hour_0">15:45</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="signals"   datasizewidth="61.0px" datasizeheight="20.0px" dataX="8.0" dataY="0.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/2428312f-563c-45ac-9402-2b1b14fc0cb4.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="360.0px" datasizeheight="212.4px" dataX="7.5" dataY="121.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c325266b-0f17-42fa-9d7d-02fbec5ac776.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="360.0px" datasizeheight="223.5px" datasizewidthpx="360.0000000000008" datasizeheightpx="223.54166666666674" dataX="7.5" dataY="355.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="360.0px" datasizeheight="216.0px" dataX="15.0" dataY="358.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Cold storages are very necessary in the vaccine distribution. &nbsp;We require companies who are willing to establish coldstorage on the land given by the government. The land can be given lease for few months to the companies for personal use. The company can use it for call centres etc. The company will also get reimbursement for the work they have done by the government. Apply now and choose the area from the given list.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="114.0px" datasizeheight="32.0px" dataX="130.5" dataY="622.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">APPLY NOW</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;