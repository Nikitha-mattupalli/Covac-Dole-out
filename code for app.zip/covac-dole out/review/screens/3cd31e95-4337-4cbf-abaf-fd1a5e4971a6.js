var content='<div class="ui-page" deviceName="iphonex" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-3cd31e95-4337-4cbf-abaf-fd1a5e4971a6" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="health places" width="375" height="812">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/3cd31e95-4337-4cbf-abaf-fd1a5e4971a6-1619920256764.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/3cd31e95-4337-4cbf-abaf-fd1a5e4971a6-1619920256764-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/3cd31e95-4337-4cbf-abaf-fd1a5e4971a6-1619920256764-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Contacts_screen" class="group firer ie-background commentable non-processed" customid="Contacts_screen" datasizewidth="352.0px" datasizeheight="592.0px" >\
        <div id="s-inbox-dinamicpanel" class="pie percentage dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="inbox-dinamicpanel" datasizewidth="100.0%" datasizeheight="100.0%" dataX="0.0" dataY="0.0" >\
          <div id="s-All" class="pie percentage panel default firer drag dragend dragstart commentable non-processed-percentage non-processed" customid="All"  datasizewidth="100.0%" datasizeheight="100.0%" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
            	<div class="layoutWrapper scrollable">\
            	  <div class="paddingLayer">\
                  <div class="freeLayout">\
                  <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group_4" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_12" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_12"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="85.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_12_0">KOLKATA</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="s-Image_110" class="pie image firer ie-background commentable non-processed" customid="Image_110"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="15.0" dataY="103.0"   alt="image" systemName="./images/9eff908c-0432-4b35-b65d-04c039bf9860.svg" overlay="#007AFF">\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" fill="#007AFF" jimofill=" " /></svg>\
\
                        </div>\
                      </div>\
                    </div>\
\
                    <div id="shapewrapper-s-Ellipse_9" customid="Ellipse_9" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="96.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_9)">\
                                        <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_9" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_9" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_9_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group_7" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_15" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_15"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="146.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_15_0">CHENNAI</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_8" customid="Ellipse_8" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="157.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_8)">\
                                        <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_8" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_8" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_8_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group_2" datasizewidth="359.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_3"   datasizewidth="359.0px" datasizeheight="61.0px" datasizewidthpx="359.0" datasizeheightpx="61.0" dataX="0.0" dataY="207.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_3_0">DELHI</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_7" customid="Ellipse_7" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="218.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_7)">\
                                        <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_7" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_7" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_7_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group_6" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_14" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_14"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="268.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_14_0">MUMBAI</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_6" customid="Ellipse_6" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="279.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_6)">\
                                        <ellipse id="s-Ellipse_6" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_6" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_6" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_6_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group_3" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_11" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_11"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="328.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_11_0">KUMBHAKONAM</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Text_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_4"   datasizewidth="12.0px" datasizeheight="24.0px" dataX="20.0" dataY="345.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Text_4_0">K</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_5" customid="Ellipse_5" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="339.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_5)">\
                                        <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_5" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_5" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_5_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Group_9" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_17"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="390.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_17_0">KHAMMAM</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="402.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_4)">\
                                        <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_4" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_4_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group_5" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_10" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_10"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="451.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_10_0">LAHORE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Text_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_5"   datasizewidth="10.1px" datasizeheight="24.0px" dataX="20.0" dataY="468.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Text_5_0">L</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="80.0" dataY="462.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_3)">\
                                        <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_3" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_3_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group_8" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_16"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="511.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_16_0">VELLORE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="81.0" dataY="522.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_2)">\
                                        <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_2" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_2_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
\
                  <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Group_10" datasizewidth="360.0px" datasizeheight="61.0px" >\
                    <div id="s-Rectangle_13" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_13"   datasizewidth="360.0px" datasizeheight="61.0px" datasizewidthpx="360.0" datasizeheightpx="61.0" dataX="0.0" dataY="568.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Rectangle_13_0">VISAKHAPATNAM</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Text_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_7"   datasizewidth="11.8px" datasizeheight="24.0px" dataX="17.0" dataY="515.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Text_7_0">V</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="42.0px" datasizeheight="42.0px" datasizewidthpx="42.0" datasizeheightpx="42.0" dataX="78.0" dataY="580.0" >\
                        <div class="backgroundLayer">\
                          <div class="colorLayer"></div>\
                          <div class="imageLayer"></div>\
                        </div>\
                        <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                            <g>\
                                <g clip-path="url(#clip-s-Ellipse_1)">\
                                        <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </g>\
                            </g>\
                            <defs>\
                                <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                        <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                        </ellipse>\
                                </clipPath>\
                            </defs>\
                        </svg>\
                        <div class="paddingLayer">\
                            <div id="shapert-s-Ellipse_1" class="content firer" >\
                                <div class="valign">\
                                    <span id="rtr-s-Ellipse_1_0"></span>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                  </div>\
\
                  <div id="s-Rectangle_18" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_18"   datasizewidth="360.0px" datasizeheight="90.0px" datasizewidthpx="360.0" datasizeheightpx="90.0" dataX="0.0" dataY="634.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_18_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  </div>\
\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Horizontal_softkeys" class="group firer ie-background commentable non-processed" customid="Horizontal_softkeys" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Softkeys-bg" class="pie percentage rectangle manualfit firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed" customid="Softkeys-bg"   datasizewidth="100.0%" datasizeheight="48.0px" datasizewidthpx="375.0" datasizeheightpx="48.0" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Softkeys-bg_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed" customid="Square"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="74.0" dataY="16.0" aspectRatio="1.0"   alt="image" systemName="./images/52ac67f1-e9e4-40d1-aef2-625618cc008b.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>recent</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
              	            <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
              	                <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Circle" class="pie image lockV firer click ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed" customid="Circle"   datasizewidth="18.0px" datasizeheight="18.0px" dataX="0.0" dataY="14.0" aspectRatio="1.0"   alt="image" systemName="./images/f7b3865c-1097-41d2-bda0-e6d4249190a2.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>home</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
              	            <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
              	                <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
              	                    <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
              	                    <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
              	                </g>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Triangle" class="pie image lockV firer click ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed" customid="Triangle"   datasizewidth="15.0px" datasizeheight="15.0px" dataX="76.0" dataY="16.0" aspectRatio="1.0"   alt="image" systemName="./images/e3c34c71-d715-4bbb-a672-b7e5bb9b4022.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              	    <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
              	    <title>back</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs></defs>\
              	    <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
              	        <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
              	            <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
              	                <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Title-bar" class="group firer ie-background commentable non-processed" customid="Title-bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Bg" class="pie percentage rectangle manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Bg"   datasizewidth="100.0%" datasizeheight="76.0px" datasizewidthpx="375.0" datasizeheightpx="76.0" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Bg_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text" class="pie richtext autofit firer ie-background commentable pin vpin-beginning hpin-center non-processed-pin non-processed" customid="Text"   datasizewidth="218.2px" datasizeheight="28.0px" dataX="0.0" dataY="44.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_0">Places for Coldstorage</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="menu"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="14.0" dataY="44.0"   alt="image" systemName="./images/842857c1-f7dd-4df9-8571-548e9fc8cadc.svg" overlay="#676767">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z" fill="#676767" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="more-vertical"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="8.0" dataY="44.0"   alt="image" systemName="./images/22211780-5319-4ed3-b159-649d8aeb27b3.svg" overlay="#676767">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" fill="#676767" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Search" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Search"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="43.0" dataY="45.0"   alt="image" systemName="./images/3cfafb61-9ff3-4a76-878a-ded9f20a812a.svg" overlay="#676767">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill="#676767" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" customid="Status-bar" datasizewidth="352.0px" datasizeheight="20.0px" >\
          <div id="s-hour" class="pie richtext manualfit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="hour"   datasizewidth="46.0px" datasizeheight="20.0px" dataX="0.0" dataY="8.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-hour_0">15:45</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="signals"   datasizewidth="61.0px" datasizeheight="20.0px" dataX="8.0" dataY="8.0"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/653ace34-416e-4302-8755-af6fe2f8da61.png" />\
            	</div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;